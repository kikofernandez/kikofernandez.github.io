# Building a Monadic Typechecker in Haskell

This folder contains information for the interview with Ericsson.

## Folder structure

```
.
├── README.md
└── artifact
    ├── README.html
    ├── README.md
    ├── README.pdf
    ├── assets
    ├── documentation
    └── typechecker-oopl
```

* `README.md`, the current file.
* `artifact/README.html`:
  * contains information on installing prerequisites,
  * explanations about the implementation in Haskell,
  * linked to the PDF experience report on building a type checker in Haskell,
  * haddock documentation (Haskell documentation and links to source code)
* `artifact/README.pdf`: same as the HTML version but in PDF.
* `assets`: contains assets to render the website and the experience report paper
* `documentation`: haddock (Haskell) documentation of functions.
* `typechecker-oopl`: contains the source code and configuration files needed to
   run the type checker. The most important one is probably `typechecker-oopl/src`
   which contains a bunch of modules. This bunch of modules are all pretty much
   the same, except that they are different iterations to the type checker.
   I provide a list of modules and their links to the sections of the paper:
   - Initial (Section 2)
   - Reader (Section 3)
   - Backtrace (Section 4)
   - Warning (Section 5)
   - Applicative (Section 6)
   - MultiError (Section 6)
   - PhantomFunctors (Section 7)
   - PhantomPhases (Another approach to Section 7)
   - Final (contains all of them).

## Interview process

I have co-written all these modules with my co-author Elias Castegren.
This code is from an experience report article where we won a Distinguished Artifact Award.
I think that a good module is `Warning`, since it contains plenty of goodies, e.g., Functors, Semigroups, etc.

(The three last modules become quite tricky to think about -- now that I have not looked at this in 2 years --
because it is difficult to get an intuition for kinds applied to a type parameter who is abstracted over a functor type class.)
