We recommend reading the rendered [HTML version](README.html) of
the documentation of this artifact.